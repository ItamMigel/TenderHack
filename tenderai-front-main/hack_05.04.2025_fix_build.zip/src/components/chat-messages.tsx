
import { ScrollShadow } from "@heroui/react";
import React from "react";


export type ChatMessagesProps = {messages: TChatMessage[]}
export default function ChatMessages (props: ChatMessagesProps) {
    const { messages } = props;

    return <div className = "h-full">
        <ScrollShadow className = "h-full space-y-4">

            {messages.map((message) => {
                return <div key = {message.id} className = "flex w-full items-start gap-x-3">
                    <img src = {message.avatarUrl} className = "size-10 rounded-full"/>
                    <div className = {`flex-1 rounded-xl px-4 py-3 text-[14px] leading-5 ${message.isSelf ? "bg-[#D4DBE6] text-[#3F3F46]" : "bg-[#E7EEF7] text-[#33333E]"}`}>
                        {message.text}
                    </div>
                </div>;
            })}
            {messages.map((message) => {
                return <div key = {message.id} className = "flex w-full items-start gap-x-3">
                    <img src = {message.avatarUrl} className = "size-10 rounded-full"/>
                    <div className = {`flex-1 rounded-xl px-4 py-3 text-[14px] leading-5 ${message.isSelf ? "bg-[#D4DBE6] text-[#3F3F46]" : "bg-[#E7EEF7] text-[#33333E]"}`}>
                        {message.text}
                    </div>
                </div>;
            })}{messages.map((message) => {
                return <div key = {message.id} className = "flex w-full items-start gap-x-3">
                    <img src = {message.avatarUrl} className = "size-10 rounded-full"/>
                    <div className = {`flex-1 rounded-xl px-4 py-3 text-[14px] leading-5 ${message.isSelf ? "bg-[#D4DBE6] text-[#3F3F46]" : "bg-[#E7EEF7] text-[#33333E]"}`}>
                        {message.text}
                    </div>
                </div>;
            })}

        </ScrollShadow>
    </div>;
}
