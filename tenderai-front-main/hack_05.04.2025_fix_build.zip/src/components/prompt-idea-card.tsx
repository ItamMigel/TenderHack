"use client";

import type { CardProps } from "@heroui/react";

import React from "react";
import { Card, CardBody, CardHeader } from "@heroui/react";
import { Icon } from "@iconify/react";
import { TPromptIdea, TPromptIdeaCard } from "@/types";


export type PromptIdeaCardProps = {card: TPromptIdeaCard};

const PromptIdeaCard = React.forwardRef<HTMLDivElement, PromptIdeaCardProps>((props, ref) => {
    const { card } = props;
    return (
        <Card ref = {ref} className = "bg-primary" shadow = "none" {...props}>
            <CardHeader className = "flex flex-col gap-2 px-4 pb-4 pt-6">
                <Icon icon = {card.iconUrl} width = {40}/>
                <p className = "text-medium text-content2-foreground">{card.title}</p>
            </CardHeader>
            <CardBody className = "flex flex-col gap-2">
                {card.ideas.map((promptIdea, index) => <div
                    key = {index}
                    className = "flex min-h-[50px] rounded-medium bg-primary-dark px-3 py-2 text-content3-foreground"
                >
                    <p className = "text-small">{promptIdea.title}</p>
                </div>)}
            </CardBody>
        </Card>
    );
},);

PromptIdeaCard.displayName = "PromptIdeaCard";

export default PromptIdeaCard;
