"use client";
import { Button } from "@heroui/react";
import React, { useEffect, useRef, useState } from "react";


export type FileInputProps = {onChange?: (file: string) => void}

export default function FileInput () {
    const inputRef = useRef<HTMLInputElement>(null);


    const [fileList, setFileList] = useState([]);


    useEffect(() => {
        if (inputRef.current) {
        }
    }, [fileList]);

    const handleAddPress = () => {
        if (inputRef.current) {
            inputRef.current.click();
        }
    };

    const handleFileOnChange = (files: FileList) => {
        const fileNames = [];
        for (const file of files) {
            const splitAr = file.name.split(".");

            const nameBeforeDot = file.name.substring(0, file.name.length - splitAr[splitAr.length - 1].length - 1);
            const name = nameBeforeDot.substring(0, Math.min(10, nameBeforeDot.length)) + "." + splitAr[splitAr.length - 1];

            fileNames.push({ name: name });
        }

        let copy = [...fileList];

        copy = copy.concat(fileNames);

        setFileList(copy);
    };

    const removeFile = (index) => {
        const copy = [...fileList];

        copy.splice(index, 1);

        setFileList(copy);
    };

    return (
        <div>
            <Button className = "mb-3 w-full" onPress = {handleAddPress}>
                <img src = "/icons/file.svg" className = "size-5"/>
                <span>Загрузить файл</span>
            </Button>
            <div className = "space-y-2">
                {fileList.map((file, index) => {
                    return <div key = {file.name} className = "flex gap-x-2 rounded-[8px] bg-[#D4D4D8] bg-opacity-40 px-2 py-1">
                        <div className = "cursor-pointer" onClick = {() => { removeFile(index); }}>Удалить</div>
                        <div className = "text-[14px] font-medium leading-[20px]">{file.name}</div>
                    </div>;
                })}
            </div>

            <input
                type = "file"
                className = "hidden"
                ref = {inputRef}
                data-testid = "uploader"
                onChange = {(e: React.ChangeEvent<HTMLInputElement>) => {
                    handleFileOnChange(e.target.files);
                }}
            />
        </div>

    );
}
