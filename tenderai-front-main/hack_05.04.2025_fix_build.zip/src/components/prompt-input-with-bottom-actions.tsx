"use client";

import PromptInput from "./prompt-input";
import React from "react";
import { Button, Tooltip, ScrollShadow, cn, Select, SelectItem } from "@heroui/react";
import { Icon } from "@iconify/react";
import { TPromptIdea } from "@/types";


const languages = [
    {
        title: "Русский",
        value: "ru"
    },
    {
        title: "Английский",
        value: "en"
    },
    {
        title: "Китайский",
        value: "cn"
    }
];
export type PromptInputWithBottomActionsProps = {promptIdeas: TPromptIdea[]}
export default function PromptInputWithBottomActions (props: PromptInputWithBottomActionsProps) {
    const { promptIdeas } = props;

    const [prompt, setPrompt] = React.useState<string>("");

    return (
        <div className = "flex w-full flex-col gap-4">
            <ScrollShadow hideScrollBar className = "flex w-full flex-nowrap gap-2 overflow-x-scroll" orientation = "horizontal">
                <div className = "flex gap-2">
                    {promptIdeas.map(({ title, description }, index) => <Button key = {index} className = "flex h-14 flex-col items-start gap-0 bg-primary" variant = "flat">
                        <p>{title}</p>
                        <p className = "text-default-500">{description}</p>
                    </Button>)}
                </div>
            </ScrollShadow>
            <Select
                placeholder = {"Выберите язык ввода"}
                className = "w-[250px]"
                classNames = {{ trigger: ["data-[hover=true]:bg-primary-dark", "bg-primary"] }}
            >
                {languages.map((language) => {
                    return <SelectItem title = {language.title} key = {language.value}/>;
                })}
            </Select>
            <form className = "flex w-full flex-col items-start rounded-medium bg-primary transition-colors hover:bg-primary-200/30">

                <PromptInput
                    classNames = {{
                        inputWrapper: "!bg-transparent shadow-none",
                        innerWrapper: "relative",
                        input: "pt-1 pl-2 pb-6 !pr-10 text-medium",
                    }}
                    endContent = {
                        <div className = "flex items-end gap-2">
                            <Tooltip showArrow content = "Send message">
                                <Button
                                    isIconOnly
                                    color = {!prompt ? "default" : "primary"}
                                    isDisabled = {!prompt}
                                    radius = "lg"
                                    size = "sm"
                                    variant = "solid"
                                >
                                    <Icon
                                        className = {cn("[&>path]:stroke-[2px]",
                                            !prompt ? "text-default-600" : "text-primary-foreground",)}
                                        icon = "solar:arrow-up-linear"
                                        width = {20}
                                    />
                                </Button>
                            </Tooltip>
                        </div>
                    }
                    minRows = {3}
                    radius = "lg"
                    value = {prompt}
                    variant = "flat"
                    onValueChange = {setPrompt}
                />
                <div className = "flex w-full items-center justify-between  gap-2 overflow-auto px-4 pb-4">
                    <div className = "flex w-full gap-1 md:gap-3">
                        <Button
                            size = "sm"
                            startContent = {
                                <Icon className = "text-default-500" icon = "solar:paperclip-linear" width = {18} />
                            }
                            variant = "flat"

                            className = "bg-primary-dark"
                        >
                            Прикрепить файл
                        </Button>
                        <Button
                            size = "sm"
                            startContent = {
                                <Icon className = "text-default-500" icon = "solar:soundwave-linear" width = {18} />
                            }
                            variant = "flat"
                            className = "bg-primary-dark"
                        >
                            Голосовое управление
                        </Button>
                    </div>
                    <p className = "py-1 text-tiny text-default-400">{prompt.length}/2000</p>
                </div>
            </form>
        </div>
    );
}
