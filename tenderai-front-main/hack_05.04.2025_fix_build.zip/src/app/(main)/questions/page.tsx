"use client";
import { questionsMock } from "@/mocks";
import { TQuestion } from "@/types";
import { Table, TableHeader, TableColumn, TableBody, TableRow, TableCell, Pagination } from "@heroui/react";
import React, { useCallback, useState } from "react";


const tableColumns = [
    {
        name: "ID вопроса",
        uid: "id"
    },
    {
        name: "Ассистент",
        uid: "assistant"
    },
    {
        name: "База знаний",
        uid: "bd"
    },
    {
        name: "Кластер",
        uid: "cluster"
    },
    {
        name: "Вопрос",
        uid: "question"
    },
    {
        name: "Оценка",
        uid: "review"
    },
    {
        name: "Дата",
        uid: "date"
    },
    {
        name: "Действия",
        uid: "actions"
    },
];
export default function QuestionsPage () {
    const renderQuestionCell = useCallback((question: TQuestion, columnKey: string) => {
        switch (columnKey) {
        case "id":
            return <div className = "text-center">
                {question.id}
            </div>;
        case "assistant":
            return <div className = "flex w-full justify-center gap-x-1.5">
                <img className = "size-10" src = {question.assistant.avatarUrl}/>
                <div>
                    <div className = "text-[14px] leading-[20px]">
                        {question.assistant.title}
                    </div>
                    <div className = "text-[12px] leading-[16px]">
                        {question.assistant.neuralNetworkTitle}
                    </div>
                </div>

            </div>;
        case "bd":
            return <div className = "text-center">
                {question.assistant.dataset.title}
            </div>;
        case "cluster":
            return <div>
                <div className = "flex h-[28px] w-fit items-center gap-x-1.5 rounded-[8px] bg-primary-dark py-1 pl-2 pr-3">
                    <div className = "size-[7px] rounded-full" style = {{ backgroundColor: question.cluster.color }}/>
                    <div className = "text-[14px] leading-[20px]">{question.cluster.title}</div>
                </div>
            </div>;
        case "question":
        {
            const selectedMessage = question.dialogue.find((message) => { return message.isSelected; });
            if (!selectedMessage) {
                return <div>Не найдено</div>;
            }
            return <div>{selectedMessage.text}</div>;
        }
        case "review":
        { const selectedMessage = question.dialogue.find((message) => { return message.isSelected; });
            if (!selectedMessage) {
                return <div>Не найдено</div>;
            }
            return <div>{selectedMessage.review}</div>;
        }
        case "date":
        {
            const dateText = new Date(question.askedAt).toLocaleDateString("ru");
            return <div>{dateText}</div>;
        }
        case "actions":
            return <div>
                Дела
            </div>;
        }
        return <div>

        </div>;
    }, []);

    const [questionsState, setQuestionsState] = useState({
        totalCount: questionsMock.length,
        createdAtOffset: Date.now(),
        questions: questionsMock,
        currentPage: 1,
        limit: 10,
    });
    return (
        <div className = "flex h-full flex-col overflow-y-auto pb-2 pt-12">
            <div>
                <div>
                    <div className = "text-[30px] font-bold leading-[36px]">Вопросы и кластеры</div>
                    <div className = "mb-6 text-[16px] leading-[24px] text-text-gray">Ознакомьтесь с вопросами</div>
                </div>
                <Table
                    isStriped
                    aria-label = "Example table with custom cells"
                    align = "center"
                    classNames = {{ tr: "" }}
                >
                    <TableHeader columns = {tableColumns} className = "bg-primary">
                        {(column) => <TableColumn key = {column.uid}>
                            {column.name}
                        </TableColumn>
                        }
                    </TableHeader>
                    <TableBody items = {questionsState.questions}>
                        {(item) => <TableRow key = {item.id}>
                            {(columnKey) => <TableCell>{renderQuestionCell(item, columnKey)}</TableCell>}
                        </TableRow>
                        }
                    </TableBody>
                </Table>
            </div>
            <div className = "min-h-0 flex-1 pb-8">
                <div className = "flex size-full flex-col items-center justify-end">
                    <Pagination classNames = {{
                        wrapper: "bg-primary",
                        prev: "bg-primary",
                        next: "bg-primary"
                    }} isCompact showControls color = "secondary" total = {Math.ceil(questionsState.totalCount / questionsState.limit)} page = {questionsState.currentPage}/>
                </div>
            </div>
        </div>

    );
}
