"use client";
import StatsChip from "@/components/stats-chip";
import { chartMock, clustersMock, statsChipsMock } from "@/mocks";
import { Button } from "@heroui/react";
import ApexCharts from "apexcharts";
import dynamic from "next/dynamic";
import React, { useEffect, useRef, useState } from "react";


const options: ApexCharts.ApexOptions = {
    chart: {
        type: "line",
        height: 410,
        toolbar: { show: false }
    },
    stroke: { curve: "smooth", },
    ...chartMock
};

const Chart = dynamic(() => import("@/components/chart"),
    { ssr: false });

export default function StatisticsPage () {
    return <div className = "flex h-full flex-col overflow-y-auto pb-2 pt-12">
        <div>
            <div className = "text-[30px] font-bold leading-[36px]">Статистика и данные</div>
            <div className = "mb-6 text-[16px] leading-[24px] text-text-gray">Ознакомьтесь с вопросами</div>
        </div>

        <div className = "flex h-[155px] shrink-0 flex-nowrap gap-x-6 overflow-x-auto bg-transparent py-2">
            {statsChipsMock.map((statsChip, index) => {
                return <div key = {index} className = "h-[135px] w-[382px] shrink-0">
                    <StatsChip stats = {statsChip}/>
                </div>;
            })}
        </div>

        <div className = "my-6 shrink-0 text-[18px] font-medium leading-[28px] text-[#3F3F46]">
            Отображение классов
        </div>
        <div className = "mb-4 flex  max-w-full shrink-0 flex-nowrap gap-x-2 overflow-x-auto">
            {clustersMock.map((questionsCluster) => {
                return <Button
                    key = {questionsCluster.id}
                    size = "sm"
                    variant = "flat"
                    className = "rounded-[8px] px-2 py-1 text-[14px] font-medium leading-[20px] text-[#000000]"
                    style = {{ backgroundColor: questionsCluster.color }}
                >
                    {questionsCluster.title}
                </Button>;
            })}

        </div>

        <Chart options = {options}/>

    </div>;
}
