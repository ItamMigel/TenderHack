
## Установка


```bash
pnpm install --frozen-lockfile
pnpm dev
```
Сайт на [http://localhost:3000](http://localhost:3000)

## Деплой

```bash
pnpm build
pnpm start
```